# source("_course_OF_dice.r") 

dice_golomb = function(...) 
{
  # golomb ruler function 
}

dice_clique = function(...) 
{
  # golomb ruler function 
}